<?php
StudipAutoloader::addAutoloadPath(__DIR__ . '/lib/classes', 'CoursewareFlow\\classes');
StudipAutoloader::addAutoloadPath(__DIR__ . '/lib/models', 'CoursewareFlow\\models');
StudipAutoloader::addAutoloadPath(__DIR__ . '/lib/JsonApi', 'CoursewareFlow\\JsonApi');

