<?php

namespace CoursewareFlow\JsonApi;

trait Schemas
{
    public function registerSchemas(): array
    {
        return [
            \CoursewareSnapshots\Models\Flow::class => Schemas\Flow::class,
        ];
    }
}